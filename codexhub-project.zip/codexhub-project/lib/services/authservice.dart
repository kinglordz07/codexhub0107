import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class AuthService {
  final SupabaseClient _supabase = Supabase.instance.client;

  // Get the current user
  User? get currentUser => _supabase.auth.currentUser;

  // Check if user is logged in
  bool get isLoggedIn => _supabase.auth.currentSession != null;

  // 🔍 Utility: Ensure profile exists or create default
  Future<String> _ensureProfile(
    User user, {
    String? username,
    String role = 'user',
  }) async {
    try {
      final profile =
          await _supabase
              .from('profiles')
              .select('role, username')
              .eq('id', user.id)
              .maybeSingle();

      if (profile == null) {
        debugPrint(
          "⚠️ No profile found for user, inserting default profile...",
        );
        await _supabase.from('profiles').insert({
          'id': user.id,
          'username': username ?? user.email!.split('@')[0],
          'email': user.email,
          'role': role,
        });
        return role;
      } else {
        return profile['role'] ?? 'user';
      }
    } catch (e) {
      debugPrint('❌ Error ensuring profile: $e');
      return 'user';
    }
  }

  // Get current user's role
  Future<String> getCurrentUserRole() async {
    try {
      final user = currentUser;
      if (user == null) return 'user';
      return await _ensureProfile(user);
    } catch (e) {
      debugPrint('❌ Error getting user role: $e');
      return 'user';
    }
  }

  // Sign up method
  Future<Map<String, dynamic>> signUp(
    String email,
    String password,
    String username, {
    String role = 'user',
  }) async {
    try {
      final response = await _supabase.auth.signUp(
        email: email,
        password: password,
      );

      final user = response.user;
      if (user == null) {
        return {'success': false, 'error': 'Sign up failed: user is null'};
      }

      // ✅ Ensure profile entry exists
      final ensuredRole = await _ensureProfile(
        user,
        username: username,
        role: role,
      );

      return {'success': true, 'role': ensuredRole};
    } catch (e) {
      return {'success': false, 'error': e.toString()};
    }
  }

  // Login method
  Future<Map<String, dynamic>> signIn(String email, String password) async {
    try {
      final response = await _supabase.auth.signInWithPassword(
        email: email,
        password: password,
      );

      final user = response.user;
      if (user != null) {
        // ✅ Ensure profile entry exists
        final ensuredRole = await _ensureProfile(user);
        return {'success': true, 'role': ensuredRole};
      } else {
        return {'success': false, 'error': 'Login failed'};
      }
    } catch (e) {
      return {'success': false, 'error': e.toString()};
    }
  }

  // Sign out method
  Future<void> signOut() async {
    await _supabase.auth.signOut();
  }
}
