import 'dart:async'; // Add this import
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:codexhub01/parts/newpass.dart';

class ResetPasswordCallback extends StatefulWidget {
  const ResetPasswordCallback({super.key});

  @override
  State<ResetPasswordCallback> createState() => _ResetPasswordCallbackState();
}

class _ResetPasswordCallbackState extends State<ResetPasswordCallback> {
  bool _isLoading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    // Don't try to access context in initState
    Future.delayed(Duration.zero, () {
      _handleResetCallback();
    });
  }

  Future<void> _handleResetCallback() async {
    try {
      // Get the current route which should contain the deep link parameters
      final route = ModalRoute.of(context);

      // Add more robust null checking
      if (route == null) {
        throw Exception('No route found');
      }

      final settings = route.settings;
      if (settings.arguments == null) {
        throw Exception('No arguments found in route settings');
      }

      if (settings.arguments is! Uri) {
        throw Exception('Arguments are not a Uri object');
      }

      final Uri deepLink = settings.arguments as Uri;
      final String? token = deepLink.queryParameters['token'];

      if (token == null || token.isEmpty) {
        throw Exception('Invalid reset link: missing token parameter');
      }

      // Use OTP verification with timeout
      final AuthResponse response = await Supabase.instance.client.auth
          .verifyOTP(token: token, type: OtpType.recovery)
          .timeout(
            const Duration(seconds: 30),
            onTimeout: () {
              throw TimeoutException('Password reset verification timed out');
            },
          );

      if (response.session == null) {
        throw Exception('Password reset failed: No session returned.');
      }

      if (!mounted) return;

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const UpdatePasswordScreen()),
      );
    } on TimeoutException catch (e) {
      debugPrint('Timeout occurred: $e');
      // Handle timeout specifically
      if (!mounted) return;
      setState(() {
        _error = 'Request timed out. Please try again.';
        _isLoading = false;
      });
    } catch (e, stackTrace) {
      // Add detailed error logging
      debugPrint('Error in _handleResetCallback: $e');
      debugPrint('Stack trace: $stackTrace');
      // Provide a default error message if e is null
      final errorMessage = e.toString();
      if (!mounted) return;

      setState(() {
        _error = 'Error: $errorMessage';
        _isLoading = false;
      });
    }
  }

  // Add a retry method
  void _retryResetCallback() {
    setState(() {
      _isLoading = true;
      _error = null;
    });
    _handleResetCallback();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Reset Password'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Center(
        child:
            _isLoading
                ? const CircularProgressIndicator()
                : Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        _error ?? 'An unknown error occurred',
                        textAlign: TextAlign.center,
                        style: const TextStyle(fontSize: 16),
                      ),
                      const SizedBox(height: 20),
                      // Add retry button for errors
                      if (_error != null)
                        ElevatedButton(
                          onPressed: _retryResetCallback,
                          child: const Text('Try Again'),
                        ),
                      const SizedBox(height: 10),
                      ElevatedButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        child: const Text('Go Back'),
                      ),
                    ],
                  ),
                ),
      ),
    );
  }
}
