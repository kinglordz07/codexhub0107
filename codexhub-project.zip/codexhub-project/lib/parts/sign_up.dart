import 'package:flutter/material.dart';
import 'package:codexhub01/parts/log_in.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'dart:async';

class SignUp extends StatefulWidget {
  const SignUp({super.key});

  @override
  State<SignUp> createState() => _SignUpState();
}

class _SignUpState extends State<SignUp> {
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _confirmPasswordController =
      TextEditingController();

  String _selectedRole = "user";
  bool _isLoading = false;
  bool _obscurePassword = true;
  bool _obscureConfirmPassword = true;
  bool _isDisposed = false; // Add disposal flag

  final SupabaseClient _supabase = Supabase.instance.client;
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  void dispose() {
    _isDisposed = true; // Mark as disposed
    _usernameController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    _confirmPasswordController.dispose();
    super.dispose();
  }

  // Safe state update method
  void _safeSetState(VoidCallback fn) {
    if (!_isDisposed && mounted) {
      setState(fn);
    }
  }

  // Safe navigation method
  void _safeNavigate(Function() navigationFunction) {
    if (!_isDisposed && mounted) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted && !_isDisposed) {
          navigationFunction();
        }
      });
    }
  }

  // Safe snackbar method
  void _safeShowSnackBar(SnackBar snackBar) {
    if (!_isDisposed && mounted) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted && !_isDisposed) {
          ScaffoldMessenger.of(context).showSnackBar(snackBar);
        }
      });
    }
  }

  String? _validateEmail(String? value) {
    if (value == null || value.isEmpty) {
      return 'Please enter your email';
    }
    final emailRegex = RegExp(r'^[^@]+@[^@]+\.[^@]+');
    if (!emailRegex.hasMatch(value)) {
      return 'Please enter a valid email address';
    }
    return null;
  }

  String? _validatePassword(String? value) {
    if (value == null || value.isEmpty) {
      return 'Please enter your password';
    }
    if (value.length < 6) {
      return 'Password must be at least 6 characters';
    }
    return null;
  }

  String? _validateConfirmPassword(String? value) {
    if (value != _passwordController.text) {
      return 'Passwords do not match';
    }
    return null;
  }

  String? _validateUsername(String? value) {
    if (value == null || value.isEmpty) {
      return 'Please enter a username';
    }
    if (value.length < 3) {
      return 'Username must be at least 3 characters';
    }
    return null;
  }

  Future<void> _signUp() async {
    if (!_formKey.currentState!.validate()) return;

    _safeSetState(() => _isLoading = true);

    try {
      final email = _emailController.text.trim();
      final password = _passwordController.text.trim();
      final username = _usernameController.text.trim();

      print('🎯 Starting signup process...');
      print('📝 Form data:');
      print('  - Username: $username');
      print('  - Email: $email');
      print('  - Role: $_selectedRole');

      // 1. Create the authentication user
      print('🔐 Step 1: Creating auth user...');
      final authResponse = await _supabase.auth.signUp(
        email: email,
        password: password,
      );

      if (authResponse.user != null) {
        print('✅ Auth successful! User ID: ${authResponse.user!.id}');

        // Wait a moment for any database triggers to complete
        await Future.delayed(const Duration(seconds: 1));

        // 2. Check if profile already exists (likely created by a trigger)
        print('🔍 Step 2: Checking for existing profile...');
        try {
          final existingProfile =
              await _supabase
                  .from('profiles')
                  .select('id, role')
                  .eq('id', authResponse.user!.id)
                  .maybeSingle(); // Use maybeSingle() instead of single()

          if (existingProfile != null) {
            print('📋 Profile already exists, updating role...');
            // Profile exists - update the role
            await _supabase
                .from('profiles')
                .update({
                  'username': username,
                  'email': email,
                  'role': _selectedRole,
                  'updated_at': DateTime.now().toIso8601String(),
                })
                .eq('id', authResponse.user!.id);
          } else {
            print('📋 Creating new profile...');
            // Profile doesn't exist - create it
            await _supabase.from('profiles').insert({
              'id': authResponse.user!.id,
              'username': username,
              'email': email,
              'role': _selectedRole,
              'created_at': DateTime.now().toIso8601String(),
            });
          }
        } catch (e) {
          print('❌ Profile check/update error: $e');
          // If there's an error, try to insert anyway
          await _supabase.from('profiles').insert({
            'id': authResponse.user!.id,
            'username': username,
            'email': email,
            'role': _selectedRole,
            'created_at': DateTime.now().toIso8601String(),
          });
        }

        // 3. Verify the role was saved
        print('🔍 Step 3: Verifying saved role...');
        final verifyResponse =
            await _supabase
                .from('profiles')
                .select('role, username, email')
                .eq('id', authResponse.user!.id)
                .single();

        print('📋 Verification data: $verifyResponse');
        final savedRole = verifyResponse['role'];
        print('🎯 Verified saved role: $savedRole');

        _safeShowSnackBar(
          SnackBar(
            content: Text(
              "✅ Account created successfully! Role: $_selectedRole",
            ),
            backgroundColor: Colors.green,
          ),
        );

        _safeNavigate(() {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (_) => const SignIn()),
          );
        });
      } else {
        print('❌ Auth failed - no user returned');
        throw Exception('Authentication failed - no user returned');
      }
    } catch (e) {
      print('🔴 Sign up error: $e');
      _safeShowSnackBar(
        SnackBar(
          content: Text("❌ Error: ${e.toString()}"),
          backgroundColor: Colors.red,
        ),
      );
    } finally {
      _safeSetState(() => _isLoading = false);
    }
  }

  // Add this new error handling method
  void _handleDatabaseError(PostgrestException e) {
    String message = "Database error occurred";

    if (e.message.contains("duplicate key") && e.message.contains("username")) {
      message = "Username already exists. Please choose a different username.";
    } else if (e.message.contains("duplicate key") &&
        e.message.contains("email")) {
      message =
          "Email already exists. Please use a different email or try logging in.";
    } else if (e.message.contains("profiles")) {
      message = "Database configuration error. Please contact support.";
    } else {
      message = e.message;
    }

    _safeShowSnackBar(
      SnackBar(
        content: Text("❌ $message"),
        backgroundColor: Colors.red,
        duration: const Duration(seconds: 5),
      ),
    );
  }

  void _handleAuthError(AuthException e) {
    String message = "Authentication failed";

    if (e.message.contains("already registered") ||
        e.code == 'user_already_exists') {
      message = "This email is already registered. Please try logging in.";
    } else if (e.message.contains("Invalid email") ||
        e.code == 'invalid_email') {
      message = "Please enter a valid email address.";
    } else if (e.message.contains("Password should be at least") ||
        e.code == 'weak_password') {
      message = "Password is too weak. Please choose a stronger password.";
    } else if (e.message.contains("Database error")) {
      message = "Server error. Please try again later.";
    } else {
      message = e.message;
    }

    _safeShowSnackBar(
      SnackBar(
        content: Text("❌ $message"),
        backgroundColor: Colors.red,
        duration: const Duration(seconds: 5),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.white, Color(0xFFE3F2FD), Colors.white],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 24),
            child: Form(
              key: _formKey,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text(
                    "Create Account",
                    style: TextStyle(
                      fontSize: 32,
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    _selectedRole == "mentor"
                        ? "Join as a coding mentor"
                        : "Start your coding journey",
                    style: TextStyle(fontSize: 16, color: Colors.grey[700]),
                  ),
                  const SizedBox(height: 30),

                  // Username Field
                  TextFormField(
                    controller: _usernameController,
                    decoration: InputDecoration(
                      labelText: "Username",
                      prefixIcon: Icon(
                        Icons.person_outline,
                        color: Colors.blue.shade700,
                      ),
                      border: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.blue.shade700),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.blue.shade700,
                          width: 2,
                        ),
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                    validator: _validateUsername,
                  ),
                  const SizedBox(height: 20),

                  // Email Field
                  TextFormField(
                    controller: _emailController,
                    decoration: InputDecoration(
                      labelText: "Email",
                      prefixIcon: Icon(
                        Icons.email_outlined,
                        color: Colors.blue.shade700,
                      ),
                      border: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.blue.shade700),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.blue.shade700,
                          width: 2,
                        ),
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                    keyboardType: TextInputType.emailAddress,
                    validator: _validateEmail,
                  ),
                  const SizedBox(height: 20),

                  // Password Field
                  TextFormField(
                    controller: _passwordController,
                    obscureText: _obscurePassword,
                    decoration: InputDecoration(
                      labelText: "Password (min. 6 characters)",
                      prefixIcon: Icon(
                        Icons.lock_outline,
                        color: Colors.blue.shade700,
                      ),
                      suffixIcon: IconButton(
                        icon: Icon(
                          _obscurePassword
                              ? Icons.visibility
                              : Icons.visibility_off,
                          color: Colors.grey,
                        ),
                        onPressed: () {
                          _safeSetState(
                            () => _obscurePassword = !_obscurePassword,
                          );
                        },
                      ),
                      border: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.blue.shade700),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.blue.shade700,
                          width: 2,
                        ),
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                    validator: _validatePassword,
                  ),
                  const SizedBox(height: 20),

                  // Confirm Password Field
                  TextFormField(
                    controller: _confirmPasswordController,
                    obscureText: _obscureConfirmPassword,
                    decoration: InputDecoration(
                      labelText: "Confirm Password",
                      prefixIcon: Icon(
                        Icons.lock_outline,
                        color: Colors.blue.shade700,
                      ),
                      suffixIcon: IconButton(
                        icon: Icon(
                          _obscureConfirmPassword
                              ? Icons.visibility
                              : Icons.visibility_off,
                          color: Colors.grey,
                        ),
                        onPressed: () {
                          _safeSetState(
                            () =>
                                _obscureConfirmPassword =
                                    !_obscureConfirmPassword,
                          );
                        },
                      ),
                      border: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.blue.shade700),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.blue.shade700,
                          width: 2,
                        ),
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                    validator: _validateConfirmPassword,
                  ),
                  const SizedBox(height: 20),

                  // Role Selection
                  const Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      "Select Your Role",
                      style: TextStyle(
                        color: Colors.black87,
                        fontWeight: FontWeight.w600,
                        fontSize: 16,
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      border: Border.all(color: Colors.blue.shade700),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: DropdownButton<String>(
                      value: _selectedRole,
                      isExpanded: true,
                      underline: const SizedBox(),
                      onChanged:
                          _isLoading
                              ? null
                              : (String? newValue) {
                                if (newValue != null) {
                                  _safeSetState(() => _selectedRole = newValue);
                                }
                              },
                      items: const [
                        DropdownMenuItem(value: "user", child: Text("user")),
                        DropdownMenuItem(
                          value: "mentor",
                          child: Text("mentor"),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 30),

                  // Sign Up Button
                  _isLoading
                      ? const CircularProgressIndicator()
                      : SizedBox(
                        width: double.infinity,
                        height: 50,
                        child: ElevatedButton(
                          onPressed: _signUp,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.blue.shade700,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8),
                            ),
                          ),
                          child: const Text(
                            "Create Account",
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),

                  const SizedBox(height: 20),

                  // Login Link
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Text("Already have an account?"),
                      TextButton(
                        onPressed:
                            _isLoading
                                ? null
                                : () {
                                  Navigator.pushReplacement(
                                    context,
                                    MaterialPageRoute(
                                      builder: (_) => const SignIn(),
                                    ),
                                  );
                                },
                        child: const Text(
                          "Login",
                          style: TextStyle(
                            color: Colors.blue,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
