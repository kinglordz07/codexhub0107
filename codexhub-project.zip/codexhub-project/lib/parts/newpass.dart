import 'dart:async';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class ResetPasswordCallback extends StatefulWidget {
  const ResetPasswordCallback({super.key});

  @override
  State<ResetPasswordCallback> createState() => _ResetPasswordCallbackState();
}

class _ResetPasswordCallbackState extends State<ResetPasswordCallback> {
  bool _isLoading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    Future.delayed(Duration.zero, () {
      _handleResetCallback();
    });
  }

  Future<void> _handleResetCallback() async {
    try {
      final route = ModalRoute.of(context);

      if (route == null) {
        throw Exception('No route found');
      }

      final settings = route.settings;
      if (settings.arguments == null) {
        throw Exception('No arguments found in route settings');
      }

      if (settings.arguments is! Uri) {
        throw Exception('Arguments are not a Uri object');
      }

      final Uri deepLink = settings.arguments as Uri;
      final String? token = deepLink.queryParameters['token'];

      if (token == null || token.isEmpty) {
        throw Exception('Invalid reset link: missing token parameter');
      }

      final AuthResponse response = await Supabase.instance.client.auth
          .verifyOTP(token: token, type: OtpType.recovery)
          .timeout(
            const Duration(seconds: 30),
            onTimeout: () {
              throw TimeoutException('Password reset verification timed out');
            },
          );

      if (response.session == null) {
        throw Exception('Password reset failed: No session returned.');
      }

      if (!mounted) return;

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const UpdatePasswordScreen()),
      );
    } on TimeoutException catch (e) {
      debugPrint('Timeout occurred: $e');
      if (!mounted) return;
      setState(() {
        _error = 'Request timed out. Please try again.';
        _isLoading = false;
      });
    } catch (e, stackTrace) {
      debugPrint('Error in _handleResetCallback: $e');
      debugPrint('Stack trace: $stackTrace');
      final errorMessage = e.toString();
      if (!mounted) return;

      setState(() {
        _error = 'Error: $errorMessage';
        _isLoading = false;
      });
    }
  }

  void _retryResetCallback() {
    setState(() {
      _isLoading = true;
      _error = null;
    });
    _handleResetCallback();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Reset Password'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Center(
        child:
            _isLoading
                ? const CircularProgressIndicator()
                : Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        _error ?? 'An unknown error occurred',
                        textAlign: TextAlign.center,
                        style: const TextStyle(fontSize: 16),
                      ),
                      const SizedBox(height: 20),
                      if (_error != null)
                        ElevatedButton(
                          onPressed: _retryResetCallback,
                          child: const Text('Try Again'),
                        ),
                      const SizedBox(height: 10),
                      ElevatedButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        child: const Text('Go Back'),
                      ),
                    ],
                  ),
                ),
      ),
    );
  }
}

class UpdatePasswordScreen extends StatefulWidget {
  const UpdatePasswordScreen({super.key});

  @override
  State<UpdatePasswordScreen> createState() => _UpdatePasswordScreenState();
}

class _UpdatePasswordScreenState extends State<UpdatePasswordScreen> {
  final _passwordController = TextEditingController();
  final _confirmPasswordController = TextEditingController();
  bool _isLoading = false;
  bool _obscurePassword = true;
  bool _obscureConfirmPassword = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Set New Password')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _passwordController,
              decoration: InputDecoration(
                labelText: 'New Password',
                suffixIcon: IconButton(
                  icon: Icon(
                    _obscurePassword ? Icons.visibility : Icons.visibility_off,
                  ),
                  onPressed: () {
                    setState(() {
                      _obscurePassword = !_obscurePassword;
                    });
                  },
                ),
              ),
              obscureText: _obscurePassword,
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _confirmPasswordController,
              decoration: InputDecoration(
                labelText: 'Confirm Password',
                suffixIcon: IconButton(
                  icon: Icon(
                    _obscureConfirmPassword
                        ? Icons.visibility
                        : Icons.visibility_off,
                  ),
                  onPressed: () {
                    setState(() {
                      _obscureConfirmPassword = !_obscureConfirmPassword;
                    });
                  },
                ),
              ),
              obscureText: _obscureConfirmPassword,
            ),
            const SizedBox(height: 20),
            _isLoading
                ? const CircularProgressIndicator()
                : ElevatedButton(
                  onPressed: _updatePassword,
                  child: const Text('Update Password'),
                ),
          ],
        ),
      ),
    );
  }

  Future<void> _updatePassword() async {
    setState(() => _isLoading = true);

    try {
      final password = _passwordController.text;
      final confirmPassword = _confirmPasswordController.text;

      if (password.isEmpty || confirmPassword.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Please fill in all fields')),
        );
        setState(() => _isLoading = false);
        return;
      }

      if (password.length < 6) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Password should be at least 6 characters long'),
          ),
        );
        setState(() => _isLoading = false);
        return;
      }

      if (password != confirmPassword) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(const SnackBar(content: Text('Passwords do not match')));
        setState(() => _isLoading = false);
        return;
      }

      // Update the password
      await Supabase.instance.client.auth.updateUser(
        UserAttributes(password: password),
      );

      if (!mounted) return;

      // Show success dialog
      await showDialog(
        context: context,
        builder:
            (context) => AlertDialog(
              title: const Text('Success'),
              content: const Text('Password updated successfully!'),
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.pop(context);
                    Navigator.popUntil(context, (route) => route.isFirst);
                  },
                  child: const Text('OK'),
                ),
              ],
            ),
      );
    } catch (e) {
      if (!mounted) return;

      String errorMessage = 'Error updating password';
      if (e is AuthException) {
        errorMessage = 'Authentication error: ${e.message}';
      } else if (e is Exception) {
        errorMessage = 'Error: ${e.toString()}';
      }

      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(errorMessage)));
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  @override
  void dispose() {
    _passwordController.dispose();
    _confirmPasswordController.dispose();
    super.dispose();
  }
}
